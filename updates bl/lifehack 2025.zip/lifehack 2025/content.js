// 1) Your patterns stay the same:
const patterns = [
  {
    category: "Quantitative recycled-content",
    description: "percentages like “X% recycled” that claim a concrete amount.",
    severity: "issue",
    regex: /\b\d+\s*%\s*recycled\b/gi
  },
  {
    category: "Partial-component call-outs",
    description: "Highlighting only one part (e.g. lining or insole) as recycled while ignoring the rest.",
    severity: "warning",
    regex: /\b(?:vamp|collar|tongue|lining|insole)\b.*\b(recycled)\b/gi
  },
  {
    category: "Unspecified Quantity Claims",
    description: "Vague terms that don’t commit to a precise number (e.g. “up to”, “almost”).",
    severity: "warning",
    regex: /\b(?:at least|up to|approximately|around|nearly|over|under|more than|less than|only|just)\b/gi
  },
  {
    category: "Vague sustainability keywords",
    description: "keywords without hard data (e.g. “slow fashion,” “upcycled”).",
    severity: "issue",
    regex: /\b(?:eco[-\s]?friendly|sustainable|natural|naturel|planet[-\s]?positive|future[-\s]?friendly|environmentally[-\s]?sound|eco[-\s]?conscious|environmentally responsible|eco[-\s]?innovation|slow[-\s]?fashion|organic\s+cotton|plant[-\s]?based\s+dyes?|fair[-\s]?trade|upcycled|cruelty[-\s]?free\s+leather|regenerative\s+agriculture|traceable\s+supply\s+chain|zero[-\s]?discharge|waterless\s+dyeing|non[-\s]?mulesed\s+wool|closed[-\s]?loop|low[-\s]?impact\s+fabric|recyclable\s+packaging)\b/gi
  }
];

// 2) Build your findings
const text = document.body.innerText;
const findings = patterns
  .map(({ category, description, severity, regex }) => {
    const matches = text.match(regex);
    return matches
      ? { category, description, severity, hits: [...new Set(matches)] }
      : null;
  })
  .filter(Boolean);

// 3) Safe highlighting via TreeWalker
function highlightText(term, className) {
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );
  const regex = new RegExp(term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
  const toWrap = [];

  let node;
  while (node = walker.nextNode()) {
    if (regex.test(node.nodeValue)) {
      toWrap.push(node);
    }
  }

  toWrap.forEach(textNode => {
    const frag = document.createDocumentFragment();
    let last = 0;
    textNode.nodeValue.replace(regex, (match, offset) => {
      frag.appendChild(document.createTextNode(textNode.nodeValue.slice(last, offset)));
      const mark = document.createElement('mark');
      mark.className = className;
      mark.textContent = match;
      frag.appendChild(mark);
      last = offset + match.length;
    });
    frag.appendChild(document.createTextNode(textNode.nodeValue.slice(last)));
    textNode.parentNode.replaceChild(frag, textNode);
  });
}

findings.forEach(({ hits, severity }) => {
  hits.forEach(term => highlightText(term, `gw-${severity}`));
});

// 4) Messaging for popup.js (unchanged)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "REQUEST_FINDINGS") {
    sendResponse({ findings });
  }
});



